/*
 * Creation : 25 Apr 2019
 */
package com.pramanda.feu;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class AppFrame extends JFrame {

    private static final long serialVersionUID = 1979785312784643757L;

    private AppFrame currentInstance;

    public AppFrame() {
        super(Constants.APP_NAME);

        this.currentInstance = this;

        init();

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
    }

    private void init() {

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout(10, 10));
        Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);
        contentPanel.setBorder(padding);
        this.setContentPane(contentPanel);

        Container container = this.getContentPane();

        JPanel northPanel = new JPanel();
        northPanel.setLayout(new BorderLayout(5, 5));

        JTextField fileOrDir = new JTextField();
        fileOrDir.setPreferredSize(new Dimension(300, 0));
        northPanel.add(fileOrDir, BorderLayout.CENTER);

        JButton browse = new JButton("Browse");

        browse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle(Constants.APP_NAME);
                chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                chooser.setAcceptAllFileFilterUsed(false);

                if (chooser.showOpenDialog(currentInstance) == JFileChooser.APPROVE_OPTION) {
                    fileOrDir.setText(chooser.getSelectedFile().getAbsolutePath());
                }
            }
        });

        northPanel.add(browse, BorderLayout.EAST);

        container.add(northPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout());

        GridBagConstraints gbc = new GridBagConstraints();

        gbc.fill = GridBagConstraints.BOTH;
        gbc.weighty = 1;
        
        JList<String> excludedList = new JList<>(new DefaultListModel<String>());
        excludedList.setOpaque(false);

        JScrollPane excludedScrollPane = new JScrollPane(excludedList);
        excludedScrollPane.setPreferredSize(new Dimension(250, 250));
        excludedScrollPane.setBorder(BorderFactory.createTitledBorder("Excluded Encodings"));

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 1;

        centerPanel.add(excludedScrollPane, gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0;

        centerPanel.add(getButtonPanel(), gbc);

        JList<String> includedList = new JList<>(new DefaultListModel<String>());
        includedList.setOpaque(false);

        JScrollPane includedScrollPane = new JScrollPane(includedList);
        includedScrollPane.setPreferredSize(new Dimension(250, 250));
        includedScrollPane.setBorder(BorderFactory.createTitledBorder("Included Encodings"));

        gbc.gridx = 2;
        gbc.gridy = 0;
        gbc.weightx = 1;

        centerPanel.add(includedScrollPane, gbc);

        container.add(centerPanel, BorderLayout.CENTER);
        
        ((DefaultListModel) excludedList.getModel()).addElement("Hello1");
        ((DefaultListModel) excludedList.getModel()).addElement("Hello2");
        
        ((DefaultListModel) includedList.getModel()).addElement("Hello1");
        ((DefaultListModel) includedList.getModel()).addElement("Hello2");

    }
    
    private Component getButtonPanel() {

        JPanel buttonPanel = new JPanel();
        //buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);
        buttonPanel.setBorder(padding);
        buttonPanel.setLayout(new GridBagLayout());
        
        GridBagConstraints gbc2 = new GridBagConstraints();
        gbc2.fill = GridBagConstraints.BOTH;
        gbc2.gridx = 0;

        buttonPanel.add(Box.createVerticalGlue());
        
        JButton includeButton = new JButton("Add >");
        gbc2.gridy = 0;
        buttonPanel.add(includeButton, gbc2);

        JButton excludeButton = new JButton("< Remove");
        gbc2.gridy = 1;
        buttonPanel.add(excludeButton, gbc2);

        buttonPanel.add(Box.createVerticalGlue());
        
        return buttonPanel;
        
    }
    
    /*FSTree tree = new FSTree(this);
    
    tree.setBackground(getBackground());
    
    JScrollPane treeScroll = new JScrollPane(tree);

    treeScroll.setBorder(BorderFactory.createTitledBorder("Files and Folders"));

    tree.setRoot(new File("C:\\"));

    tree.getRoot().add(new File("C:\\Users"));

    tree.setExpanded(true);
    
    gbc.gridx = 0;
    gbc.gridy = 1;
    gbc.weightx = 1;
    gbc.gridwidth = 3;
    
    centerPanel.add(treeScroll, gbc);*/

}
