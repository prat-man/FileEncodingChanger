/*
 * Creation : 25 Apr 2019
 */
package com.pramanda.feu;

public class Constants {

    public static String APP_NAME = "File Encoding Utils";

}
