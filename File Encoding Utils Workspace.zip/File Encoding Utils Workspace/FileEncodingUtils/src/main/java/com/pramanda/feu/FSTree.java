/*
 * Creation : 26 Apr 2019
 */
package com.pramanda.feu;

import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class FSTree extends JTree {

	private static final long serialVersionUID = 5062793994719994248L;
	
	private int hoverRow = -1;

	public FSTree(AppFrame frame) {

		setModel(new DefaultTreeModel(null));

		setOpaque(false);
		setShowsRootHandles(true);
		setCellRenderer(new FSTreeCellRenderer());

		setUI(new javax.swing.plaf.basic.BasicTreeUI() {
			@Override
			public Rectangle getPathBounds(JTree tree, TreePath path) {
				if (tree != null && treeState != null) {
					return getPathBounds(path, tree.getInsets(), new Rectangle());
				}
				return null;
			}

			private Rectangle getPathBounds(TreePath path, Insets insets, Rectangle bounds) {
				bounds = treeState.getBounds(path, bounds);
				if (bounds != null) {
					bounds.width = tree.getWidth();
					bounds.y += insets.top;
				}
				return bounds;
			}
		});

		addMouseMotionListener(new MouseMotionAdapter() {
			@Override
			public void mouseMoved(MouseEvent event) {
				Point p = event.getPoint();
				int selRow = getRowForLocation(p.x, p.y);
				if (selRow != -1) {
					hoverRow = selRow;
					setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				} else {
					hoverRow = -1;
					setCursor(Cursor.getDefaultCursor());
				}
				repaint();
			}
		});

		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {

				TreePath path = getClosestPathForLocation(e.getX(), e.getY());

				int selRow = getRowForLocation(e.getX(), e.getY());

				setSelectionRow(selRow);

				if (selRow != -1 && path != null) {
					FSTreeNode node = (FSTreeNode) path.getLastPathComponent();

					if (e.getButton() == MouseEvent.BUTTON1) {
						if (e.getClickCount() >= 2) {
							JOptionPane.showMessageDialog(frame, node.getUserObject(), Constants.APP_NAME, JOptionPane.INFORMATION_MESSAGE);
						} else {
							if (isCollapsed(getRowForLocation(e.getX(), e.getY()))) {
								expandRow(getRowForLocation(e.getX(), e.getY()));
							} else {
								collapseRow(getRowForLocation(e.getX(), e.getY()));
							}
						}
					} else if (e.getButton() == MouseEvent.BUTTON3) {
						try {
							Desktop desktop = Desktop.getDesktop();
							desktop.open((File) node.getUserObject());
						} catch (IOException e1) {
							e1.printStackTrace();
						}
					}
				}
			}
			
			@Override
			public void mouseExited(MouseEvent event) {
				hoverRow = -1;
				repaint();
			}
		});
	}

	@Override
	public int getRowForLocation(int x, int y) {
		int closestRow = getClosestRowForLocation(x, y);

		Rectangle closestRowBounds = getRowBounds(closestRow);
		if ((y >= closestRowBounds.getY() && y < closestRowBounds.getY() + closestRowBounds.getHeight())
				&& (x > closestRowBounds.getX() && closestRow < getRowCount())) {
			return closestRow;
		} else {
			return -1;
		}
	}

	@Override
	public void paintComponent(Graphics g) {
		if (hoverRow != -1) {
			Rectangle r = getRowBounds(hoverRow);
			g.setColor(Color.lightGray);
			g.fillRect(0, r.y, getWidth() - 1, r.height - 1);
		}
		if (getLeadSelectionPath() != null) {
			Rectangle r = getRowBounds(getRowForPath(getLeadSelectionPath()));
			g.setColor(new JList<>().getSelectionBackground());
			g.fillRect(0, r.y, getWidth() - 1, r.height - 1);
		}
		
        super.paintComponent(g);
	}

	public void setRoot(File file) {
		FSTreeNode root = new FSTreeNode(file);
		DefaultTreeModel model = new DefaultTreeModel(root);
		setModel(model);
	}

	public FSTreeNode getRoot() {
		return (FSTreeNode) getModel().getRoot();
	}

	public void setExpanded(boolean expanded) {
		FSTreeNode node = (FSTreeNode) getModel().getRoot();
		setNodeExpanded(node, expanded);
	}

	private void setNodeExpanded(FSTreeNode node, boolean expanded) {
		@SuppressWarnings("unchecked")
		ArrayList<TreeNode> list = Collections.list(node.children());
		for (TreeNode treeNode : list) {
			setNodeExpanded((FSTreeNode) treeNode, expanded);
		}
		if (!expanded && node.isRoot()) {
			return;
		}
		TreePath path = new TreePath(node.getPath());
		if (expanded) {
			expandPath(path);
		} else {
			collapsePath(path);
		}
	}

	class FSTreeCellRenderer extends DefaultTreeCellRenderer {

		private static final long serialVersionUID = -1678676336345488447L;

		private FileSystemView fsv = FileSystemView.getFileSystemView();

		@Override
		public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
				boolean leaf, int row, boolean hasFocus) {
			super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
			if (value instanceof FSTreeNode) {
				value = ((FSTreeNode) value).getUserObject();
				if (value instanceof File) {
					File file = (File) value;
					setIcon(fsv.getSystemIcon(file));

					if (file.getName().length() > 0) {
						setText(file.getName());
					} else if (file.getPath().length() > 0) {
						setText(file.getPath());
					} else {
						setText(file.getAbsolutePath());
					}
				}
			}
			return this;
		}
	}

	class FSTreeNode extends DefaultMutableTreeNode {

		private static final long serialVersionUID = 8563175715704172960L;

		public FSTreeNode() {
			super();
		}

		public FSTreeNode(Object userObject, boolean allowsChildren) {
			super(userObject, allowsChildren);
		}

		public FSTreeNode(Object userObject) {
			super(userObject);
		}

		public void add(File file) {
			add(new FSTreeNode(file));
		}

	}

}
