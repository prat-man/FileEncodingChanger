/*
 * Creation : 19 Feb 2019
 */
package com.pramanda.feu;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class FileEncodingChanger implements Runnable {

    private File file;
    private String encodingFrom;
    private String encodingTo;
    private String[] extensions;

    public FileEncodingChanger(File file, String encodingFrom, String encodingTo, String... extensions) {
        this.file = file;
        this.encodingFrom = encodingFrom;
        this.encodingTo = encodingTo;
        this.extensions = extensions;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getEncodingFrom() {
        return encodingFrom;
    }

    public void setEncodingFrom(String encodingFrom) {
        this.encodingFrom = encodingFrom;
    }

    public String getEncodingTo() {
        return encodingTo;
    }

    public void setEncodingTo(String encodingTo) {
        this.encodingTo = encodingTo;
    }

    public String[] getExtensions() {
        return extensions;
    }

    public void setExtensions(String[] extensions) {
        this.extensions = extensions;
    }

    private void changeEncoding(File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files) {
                System.out.println("DIR: " + f.getAbsolutePath());
                changeEncoding(f);
            }
        } else if (isAcceptableType(file)) {
            try {
                System.out.println("FILE: " + file.getAbsolutePath());
                String content = FileUtils.readFileToString(file, encodingFrom);
                FileUtils.write(file, content, encodingTo);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private boolean isAcceptableType(File file) {
        // if extensions list is empty, accept all file types
        if (extensions == null || extensions.length == 0) {
            return true;
        }

        // otherwise check if file is acceptable
        for (String ext : extensions) {
            if (file.getName().toLowerCase().endsWith(ext)) {
                return true;
            }
        }

        return false;
    }

    public void run() {
        changeEncoding(this.file);
    }
}
