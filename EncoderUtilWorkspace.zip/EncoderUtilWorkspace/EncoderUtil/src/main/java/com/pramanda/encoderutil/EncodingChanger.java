/*
 * Creation : 19 Feb 2019
 */
package com.pramanda.encoderutil;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

public class EncodingChanger implements Runnable {

    private File file;
    private String encodingFrom;
    private String encodingTo;

    public EncodingChanger(File file, String encodingFrom, String encodingTo) {
        this.file = file;
        this.encodingFrom = encodingFrom;
        this.encodingTo = encodingTo;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getEncodingFrom() {
        return encodingFrom;
    }

    public void setEncodingFrom(String encodingFrom) {
        this.encodingFrom = encodingFrom;
    }

    public String getEncodingTo() {
        return encodingTo;
    }

    public void setEncodingTo(String encodingTo) {
        this.encodingTo = encodingTo;
    }

    public void changeEncoding(File file) {
        if (file.isDirectory()) {
            File[] files = file.listFiles();
            for (File f : files) {
                System.out.println("DIR: " + f.getAbsolutePath());
                changeEncoding(f);
            }
        } else if (file.getName().toLowerCase().endsWith(".java")) {
            try {
                System.out.println("FILE: " + file.getAbsolutePath());
                String content = FileUtils.readFileToString(file, encodingFrom);
                FileUtils.write(file, content, encodingTo);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void run() {
        changeEncoding(this.file);
    }
}
