/*
 * Creation : 19 Feb 2019
 */
package com.pramanda.encoderutil;

import java.io.File;

public class Main {

    public static void main(String[] args) {
        File file = new File("C:\\Users\\E524459\\Desktop\\mau");
        EncodingChanger eu = new EncodingChanger(file, "ISO8859_1", "UTF-8");
        Thread thread = new Thread(eu);
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Completed");
    }

}
