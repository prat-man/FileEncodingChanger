/*
 * Author: Pratanu Mandal
 * Created: 19 Feb 2019
 * Updated: 24 Apr 2019
 */

package com.pramanda.feu;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;

public class FileEncodingChanger implements Runnable {

    private File file;
    private String encodingFrom;
    private String encodingTo;
    private String[] extensions;
    private boolean indented;
    private boolean showFullPath;

    private int dirCount;
    private int fileCount;

    public FileEncodingChanger(File file, String encodingFrom, String encodingTo, String... extensions) {
        this.file = file;
        this.encodingFrom = encodingFrom;
        this.encodingTo = encodingTo;
        this.extensions = extensions;
        this.indented = true;
        this.showFullPath = false;

        this.dirCount = 0;
        this.fileCount = 0;
    }

    public File getFile() {
        return file;
    }

    public void setFile(File file) {
        this.file = file;
    }

    public String getEncodingFrom() {
        return encodingFrom;
    }

    public void setEncodingFrom(String encodingFrom) {
        this.encodingFrom = encodingFrom;
    }

    public String getEncodingTo() {
        return encodingTo;
    }

    public void setEncodingTo(String encodingTo) {
        this.encodingTo = encodingTo;
    }

    public String[] getExtensions() {
        return extensions;
    }

    public void setExtensions(String[] extensions) {
        this.extensions = extensions;
    }

    public boolean isIndented() {
        return indented;
    }

    public void setIndented(boolean indented) {
        this.indented = indented;
    }

    public boolean isFullPathShown() {
        return showFullPath;
    }

    public void showFullPath(boolean showFullPath) {
        this.showFullPath = showFullPath;
    }

    public int getDirCount() {
        return dirCount;
    }

    public int getFileCount() {
        return fileCount;
    }

    private void changeEncoding(File file) {
        changeEncoding(file, 0);
    }

    private void changeEncoding(File file, int level) {
        StringBuilder indent = new StringBuilder();
        if (this.isIndented()) {
            for (int i = 0; i < level; i++) {
                if (i == level - 1) {
                    indent.append("|__");
                } else {
                    indent.append("|  ");
                }
            }
        }
        if (file.isDirectory()) {
            System.out.println(indent + "DIR: " + (isFullPathShown() ? file.getAbsolutePath() : file.getName()));
            File[] files = file.listFiles();
            for (File f : files) {
                changeEncoding(f, level + 1);
                this.dirCount++;
            }
        } else if (isAcceptableType(file)) {
            System.err.println(indent + "FILE: " + (isFullPathShown() ? file.getAbsolutePath() : file.getName()));

            // try to change the encoding of the file
            boolean result = this.changeFileEncoding(file);

            if (result) {
                this.fileCount++;
            } else {
                System.err.println("[ERROR] Failed to process file - " + file.getAbsolutePath());
            }
        }
    }

    private boolean changeFileEncoding(File inFile) {
        // create temporary file
        File outFile = null;
        try {
            outFile = File.createTempFile("fec", ".tmp");
        } catch (IOException e) {
            System.err.println("[ERROR] Failed to create temporary file.");
            return false;
        }

        try ( // try-with-resources
                Reader in = new InputStreamReader(new FileInputStream(inFile), encodingFrom); // reader
                Writer out = new OutputStreamWriter(new FileOutputStream(outFile), encodingTo); // writer
        ) {
            char[] cbuf = new char[4096]; // buffer to hold a chunk of data
            int len; // length of characters read
            while ((len = in.read(cbuf, 0, cbuf.length)) != -1) {
                out.write(cbuf, 0, len);
            }
        } catch (IOException e) {
            System.err.println("[ERROR] " + e.getMessage());
            return false;
        }

        // rename outFile to inFile
        return inFile.delete() && outFile.renameTo(inFile);
    }

    private boolean isAcceptableType(File file) {
        // if extensions list is empty, accept all file types
        if (extensions == null || extensions.length == 0) {
            return true;
        }

        // otherwise check if file is acceptable
        for (String ext : extensions) {
            if (file.getName().toLowerCase().endsWith(ext)) {
                return true;
            }
        }

        return false;
    }

    public void run() {
        changeEncoding(this.file);
    }
}
