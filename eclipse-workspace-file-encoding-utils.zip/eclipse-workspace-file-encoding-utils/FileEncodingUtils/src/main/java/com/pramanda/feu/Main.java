/*
 * Creation : 19 Feb 2019
 */
package com.pramanda.feu;

import java.io.File;

public class Main {

    public static void main(String[] args) {

        String dirPath = "C:\\Users\\E524459\\Desktop\\mau";

        File file = new File(dirPath);

        FileEncodingChanger eu = new FileEncodingChanger(file, "ISO8859_1", "UTF-8", ".java");
        Thread thread = new Thread(eu);
        thread.start();

        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Completed");
    }

}
