/*
 * Author: Pratanu Mandal
 * Created: 19 Feb 2019
 * Updated: 24 Apr 2019
 */

package com.pramanda.feu;

import java.awt.Color;

import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class Main {

    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
            e.printStackTrace();
        }

        UIManager.put("Tree.rendererFillBackground", false);
        UIManager.put("Tree.selectionForeground", Color.black);
        UIManager.put("Tree.selectionBackground", Color.black);
        UIManager.put("Tree.selectionBorderColor", new JPanel().getBackground());

        AppFrame frame = new AppFrame();

        frame.setVisible(true);

        /*
         * String dirPath = "C:\\Users\\E556694\\Desktop\\eclipse-workspace-routeur-mau";
         * 
         * File file = new File(dirPath);
         * 
         * FileEncodingChanger fec = new FileEncodingChanger(file, "ISO8859_1", "UTF-8", ".java");
         * 
         * Thread thread = new Thread(fec); thread.start();
         * 
         * try { thread.join(); } catch (InterruptedException e) { e.printStackTrace(); }
         * 
         * System.err.println("\nCompleted");
         * 
         * System.err.println("\nDirectories Traversed: " + fec.getDirCount()); System.err.println("Files Modified: " + fec.getFileCount());
         */
    }

}
