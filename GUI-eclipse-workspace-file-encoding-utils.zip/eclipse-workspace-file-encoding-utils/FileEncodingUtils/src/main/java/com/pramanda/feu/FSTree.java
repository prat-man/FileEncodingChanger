/*
 * Creation : 26 Apr 2019
 */
package com.pramanda.feu;

import java.awt.Component;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.filechooser.FileSystemView;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

public class FSTree extends JTree {

    private static final long serialVersionUID = 5062793994719994248L;

    public FSTree(AppFrame frame) {

        setModel(new DefaultTreeModel(null));

        setBackground(null);
        setShowsRootHandles(true);
        setCellRenderer(new FSTreeCellRenderer());

        addMouseMotionListener(new MouseMotionAdapter() {
            @Override
            public void mouseMoved(MouseEvent event) {
                Point p = event.getPoint();
                int selRow = getRowForLocation(p.x, p.y);
                if (selRow != -1) {
                    setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
                } else {
                    setCursor(Cursor.getDefaultCursor());
                }
            }
        });

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                if (e.getButton() == MouseEvent.BUTTON3) {
                    try {
                        TreePath path = getClosestPathForLocation(e.getX(), e.getY());

                        if (path != null) {
                            DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
                            Desktop desktop = Desktop.getDesktop();
                            desktop.open((File) node.getUserObject());
                        }
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                } else {
                    TreePath path = getSelectionPath();

                    if (path != null) {
                        DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();

                        if (node.isLeaf()) {
                            JOptionPane.showMessageDialog(frame, node.getUserObject(), Constants.APP_NAME, JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            if (isCollapsed(getRowForLocation(e.getX(), e.getY()))) {
                                expandRow(getRowForLocation(e.getX(), e.getY()));
                            } else {
                                collapseRow(getRowForLocation(e.getX(), e.getY()));
                            }
                        }
                    }
                }
            }
        });
    }

    public void setRoot(Object object) {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(object);
        DefaultTreeModel model = new DefaultTreeModel(root);
        setModel(model);
    }

    public DefaultMutableTreeNode getRoot() {
        return (DefaultMutableTreeNode) getModel().getRoot();
    }

    public void setExpanded(boolean expanded) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) getModel().getRoot();
        setNodeExpanded(node, expanded);
    }

    private void setNodeExpanded(DefaultMutableTreeNode node, boolean expanded) {
        @SuppressWarnings("unchecked")
        ArrayList<DefaultMutableTreeNode> list = Collections.list(node.children());
        for (DefaultMutableTreeNode treeNode : list) {
            setNodeExpanded(treeNode, expanded);
        }
        if (!expanded && node.isRoot()) {
            return;
        }
        TreePath path = new TreePath(node.getPath());
        if (expanded) {
            expandPath(path);
        } else {
            collapsePath(path);
        }
    }

    class FSTreeCellRenderer extends DefaultTreeCellRenderer {

        private static final long serialVersionUID = -1678676336345488447L;

        private FileSystemView fsv = FileSystemView.getFileSystemView();

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row,
                boolean hasFocus) {
            super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
            if (value instanceof DefaultMutableTreeNode) {
                value = ((DefaultMutableTreeNode) value).getUserObject();
                if (value instanceof File) {
                    File file = (File) value;
                    setIcon(fsv.getSystemIcon(file));

                    if (file.getName().length() > 0) {
                        setText(file.getName());
                    } else if (file.getPath().length() > 0) {
                        setText(file.getPath());
                    } else {
                        setText(file.getAbsolutePath());
                    }
                }
            }
            return this;
        }
    }

}
