/*
 * Creation : 25 Apr 2019
 */
package com.pramanda.feu;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class AppFrame extends JFrame {

    private static final long serialVersionUID = 1979785312784643757L;

    private AppFrame currentInstance;

    public AppFrame() {
        super(Constants.APP_NAME);

        this.currentInstance = this;

        init();

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.pack();
        this.setLocationRelativeTo(null);
    }

    private void init() {

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout(10, 10));
        Border padding = BorderFactory.createEmptyBorder(10, 10, 10, 10);
        contentPanel.setBorder(padding);
        this.setContentPane(contentPanel);

        Container container = this.getContentPane();

        JPanel northPanel = new JPanel();
        northPanel.setLayout(new BorderLayout(5, 5));

        JTextField fileOrDir = new JTextField();
        fileOrDir.setPreferredSize(new Dimension(300, 0));
        northPanel.add(fileOrDir, BorderLayout.CENTER);

        JButton browse = new JButton("Browse");

        browse.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();
                chooser.setDialogTitle(Constants.APP_NAME);
                chooser.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);
                chooser.setAcceptAllFileFilterUsed(false);

                if (chooser.showOpenDialog(currentInstance) == JFileChooser.APPROVE_OPTION) {
                    fileOrDir.setText(chooser.getSelectedFile().getAbsolutePath());
                }
            }
        });

        northPanel.add(browse, BorderLayout.EAST);

        container.add(northPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new GridBagLayout());

        GridBagConstraints c = new GridBagConstraints();

        c.fill = GridBagConstraints.BOTH;
        c.weighty = 1;

        /*
         * FSTree tree = new FSTree(this);
         * 
         * JScrollPane treeScroll = new JScrollPane(tree);
         * 
         * treeScroll.setBorder(BorderFactory.createTitledBorder("Files and Folders"));
         * 
         * centerPanel.add(treeScroll, BorderLayout.CENTER);
         */

        JList<String> excludedList = new JList<>(new DefaultListModel<String>());
        excludedList.setBackground(getBackground());

        JScrollPane excludedScrollPane = new JScrollPane(excludedList);
        excludedScrollPane.setPreferredSize(new Dimension(250, 250));
        excludedScrollPane.setBorder(BorderFactory.createTitledBorder("Excluded Encodings"));

        // DefaultListModel<String> listModel1 = (DefaultListModel<String>) excludedList.getModel();

        c.gridx = 0;
        c.gridy = 0;
        c.weightx = 1;

        centerPanel.add(excludedScrollPane, c);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));

        buttonPanel.add(Box.createVerticalGlue());

        JButton includeButton = new JButton(">");
        buttonPanel.add(includeButton);

        JButton excludeButton = new JButton("<");
        buttonPanel.add(excludeButton);

        buttonPanel.add(Box.createVerticalGlue());

        c.gridx = 1;
        c.gridy = 0;
        c.weightx = 0;

        centerPanel.add(buttonPanel, c);

        JList<String> includedList = new JList<>(new DefaultListModel<String>());
        includedList.setBackground(getBackground());

        JScrollPane includedScrollPane = new JScrollPane(includedList);
        includedScrollPane.setPreferredSize(new Dimension(250, 250));
        includedScrollPane.setBorder(BorderFactory.createTitledBorder("Included Encodings"));

        // DefaultListModel<String> listModel2 = (DefaultListModel<String>) includedList.getModel();

        c.gridx = 2;
        c.gridy = 0;
        c.weightx = 1;

        centerPanel.add(includedScrollPane, c);

        container.add(centerPanel, BorderLayout.CENTER);

        // tree.setExpanded(true);

    }

}
